import React from 'react';

const TextWidget = ({ content, onRemove }) => {
    return (
        <div className="p-4 bg-white rounded shadow relative">
            <button onClick={onRemove} className="absolute top-2 right-2 text-red-500 font-bold">×</button>
            <p className="text-gray-800">{content}</p>
        </div>
    );
};

export default React.memo(TextWidget);
