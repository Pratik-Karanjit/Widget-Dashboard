import React from 'react';

const TableWidget = ({ columns = [], rows = [], onRemove }) => {
    return (
        <div className="p-4 bg-white rounded shadow relative overflow-x-auto">
            <button onClick={onRemove} className="absolute top-2 right-2 text-red-500 font-bold">×</button>
            <table className="min-w-full text-left border border-gray-300">
                <thead className="bg-gray-100 text-gray-700 font-semibold">
                    <tr>
                        {columns.map((col, i) => (
                            <th key={i} className="border-b px-3 py-2">{col}</th>
                        ))}
                    </tr>
                </thead>
                <tbody>
                    {rows.map((row, i) => (
                        <tr key={i} className="text-sm text-gray-800">
                            {row.map((cell, j) => (
                                <td key={j} className="border-t px-3 py-2">{cell}</td>
                            ))}
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default React.memo(TableWidget);
