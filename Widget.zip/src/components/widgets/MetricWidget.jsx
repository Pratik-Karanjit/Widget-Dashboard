import React from 'react';

const MetricWidget = ({ metricLabel, value, onRemove }) => {
    return (
        <div className="p-4 bg-white rounded shadow relative">
            <button onClick={onRemove} className="absolute top-2 right-2 text-red-500 font-bold">×</button>
            <h2 className="text-lg font-semibold">{metricLabel}</h2>
            <p className="text-3xl text-blue-600 mt-2">{value}</p>
        </div>
    );
};

export default React.memo(MetricWidget);
