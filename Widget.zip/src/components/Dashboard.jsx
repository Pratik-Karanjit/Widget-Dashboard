// components/Dashboard.jsx
import React, { useCallback, useContext, useRef } from 'react';
import { WidgetContext } from '../context/WidgetContext';
import WidgetRenderer from './WidgetRenderer';

const Dashboard = () => {
    const { widgets, removeWidget, reorderWidgets } = useContext(WidgetContext);
    const dragItem = useRef();
    const dragOverItem = useRef();

    const handleDragStart = (index) => {
        dragItem.current = index;
    };

    const handleDragEnter = (index) => {
        dragOverItem.current = index;
    };

    const handleDragEnd = () => {
        const from = dragItem.current;
        const to = dragOverItem.current;
        if (from !== to) {
            reorderWidgets(from, to);
        }
        dragItem.current = null;
        dragOverItem.current = null;
    };

    const handleRemove = useCallback((id) => {
        removeWidget(id);
    }, [removeWidget]);

    return (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {widgets.map((widget, index) => (
                <div
                    key={widget.id}
                    draggable
                    onDragStart={() => handleDragStart(index)}
                    onDragEnter={() => handleDragEnter(index)}
                    onDragEnd={handleDragEnd}
                >

                    <WidgetRenderer
                        key={widget.id}
                        widget={widget}
                        onRemove={() => handleRemove(widget.id)}
                    />
                </div>
            ))}
        </div>
    );
};

export default Dashboard;
