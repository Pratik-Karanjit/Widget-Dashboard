import React, { useContext } from 'react';
import Dashboard from './components/Dashboard';
import { WidgetContext } from './context/WidgetContext';

const App = () => {
  const { addWidget } = useContext(WidgetContext);

  return (
    <div className="min-h-screen bg-gray-100 p-4">
      <h1 className="text-2xl font-bold mb-4">Widget Dashboard</h1>
      <div className="mb-4 space-x-2">
        <button onClick={() => addWidget('text')} className="bg-blue-500 text-white px-4 py-2 rounded">Add Text</button>
        <button onClick={() => addWidget('chart')} className="bg-green-500 text-white px-4 py-2 rounded">Add Chart</button>
        <button onClick={() => addWidget('metric')} className="bg-purple-500 text-white px-4 py-2 rounded">Add metric</button>
        <button onClick={() => addWidget('table')} className="bg-yellow-500 text-white px-4 py-2 rounded">Add Table</button>
      </div>
      <Dashboard />
    </div>
  );
};

export default App;
